package com.upgrad.hirewheels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HirewheelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HirewheelsApplication.class, args);
	}

}
